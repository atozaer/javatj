package kr.co.tj1;

public class Person {
	String pname;

	
	public Person(String pname) {
		this.pname = pname;
	}
	
	@Override
	public String toString() {
		return pname;
	}
	
	
}
